package msb.platto.commons;

public enum ConfType {
	TEXT,
	INTEGER,
	FLOAT,
	BOOLEAN,
	LIST,
	DATETIME
}
