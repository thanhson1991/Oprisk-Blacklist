package msb.platto.commons

import java.beans.PropertyEditorSupport
import java.text.ParseException
import org.apache.commons.lang.time.DateUtils
import org.springframework.beans.PropertyEditorRegistrar
import org.springframework.beans.PropertyEditorRegistry

class DateRegistrar implements PropertyEditorRegistrar {
	def dateEditor
	
	void registerCustomEditors(PropertyEditorRegistry registry) {
		registry.registerCustomEditor(Date.class, dateEditor)
	}
}

class CustomDateEditor extends PropertyEditorSupport {
	boolean allowEmpty
	String[] formats

	void setAsText(String text) throws IllegalArgumentException {
		if (this.allowEmpty && !text) {
			setValue(null)
		}
		else {
			try {
				setValue(DateUtils.parseDate(text, formats))
			}
			catch (ParseException ex) {
				throw new IllegalArgumentException("Could not parse date: " + ex.getMessage(), ex)
			}
		}
	}

	String getAsText() {
		def val = getValue()
		val?.respondsTo('format') ? val.format(formats[0]) : ''
	}
}