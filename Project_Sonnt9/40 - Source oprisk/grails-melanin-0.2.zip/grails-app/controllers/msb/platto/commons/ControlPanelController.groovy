package msb.platto.commons

class ControlPanelController {

    def index = {
		render view:'/m-melanin-control-panel/m-melanin-control-panel'
	}
	
	def conf = {
		render view:'/m-melanin-control-panel/m-melanin-control-panel-conf'
	}
	
	def addConf = {
		if (params.confId){
			redirect action:'editConf',params:params
			return
		}
		Conf conf = new Conf(params).save(flush:true)
		redirect action:'conf'
	}
	
	def editConf = {
		Conf conf = Conf.get(params.confId.toLong())
		conf.properties = params
		conf.save(flush:true)
		redirect action:'conf'
	}
	
	def deleteConf = {
		Conf conf = Conf.get(params.id.toLong())
		conf.delete(flush:true)
		redirect action:'conf'
	}
}
