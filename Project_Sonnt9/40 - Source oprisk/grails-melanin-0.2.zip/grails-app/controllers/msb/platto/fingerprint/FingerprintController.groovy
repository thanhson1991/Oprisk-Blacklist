package msb.platto.fingerprint

import org.springframework.security.authentication.dao.SaltSource;

import grails.converters.JSON;
import msb.platto.fingerprint.*

class FingerprintController {
	
	def springSecurityService

    def index = {
		render view:'/m-melanin-fingerprint/m-melanin-fingerprint'
	}

	// BRANCH MANAGEMENT ----------------
	def branch = {
		render view:'/m-melanin-fingerprint/m-melanin-fingerprint-branch'
	}
	def getBranchTree = {
		def tree = []
		def rootNodes = Branch.findAllByParentIsNull()
		
		rootNodes.each{
			tree << getSubBranchesAsJson(it)
		}
		
		render tree as JSON
	}

	def getSubBranchesAsJson(def branch){
		def currentNode = [data:branch.name,attr:[id:branch.id,code:branch.code]]
		def children = []
		branch.children.each{ 
			children << getSubBranchesAsJson(it)
		}
		currentNode['children']=children
		return currentNode
	}
	
	def getBranch = {
		def result = [:]
		def branch = Branch.get(params.id)
		result << [branch:branch]
		result << [users:branch.users]
		render result as JSON
	}
	def saveBranch = {
    	def branch = new Branch()
		if(params.id) branch = Branch.get(params.id)
		branch.properties = params
		render branch.save(flush:true)
		flash.message = "Dữ liệu được cập nhật thành công."
	}
	def addUserToBranch = {
		def user = User.get(params.id)
		def branch = Branch.get(params.branch.toLong())
		
		if(branch.users.contains(user)){
			render '-1'
			return
		}
		branch.addToUsers(user)
		branch.save(flush:true)
		render user as JSON
	}
	def removeUserFromBranch = {
		def user = User.get(params.id)
		def branch = Branch.get(params.branch.toLong())
		
		if(branch.users.contains(user)){
			branch.users.remove(user)
			branch.save(flush:true)
			user.branch = null
			user.save(flush:true)
			render 1 
			return
		}
		render '-1'
	}
	def searchUser = {
		def users = User.findAllByFullnameLikeOrUsernameLike(params.term+"%",params.term+"%",[max:20,sort:'fullname'])
		render users as JSON
	}
	

	// USER MANAGEMENT ----------------
	def user = {
		render view:'/m-melanin-fingerprint/m-melanin-fingerprint-user'
	}
	

	def addUser = {
		if (params.userId){
			redirect action:'editUser', params:params
			return
		}
		
		if(User.findByUsername(params.username)){
			flash.error="Username đã tồn tại trong hệ thống, vui lòng chọn tên khác."
			redirect action:'user'
		}
		
		User user = new User(params)
		if (!params.password){
			user.password = '1'
		}
		user.save(flush:true)
		Role role
		if (params.roles){
			if (params.roles.class.name.equals('java.lang.String')){
				UserRole.create user, Role.findByAuthority(params.roles)
			} else{
				params.roles.each{
					UserRole.create user, Role.findByAuthority(it)
				}
			}
		}
		redirect action:'user'
	}
	
	def editUser = {
		User user = User.get(params.userId)
		if(params.password == '') params.remove('password')
		user.properties = params
		user.save(flush:true)
		UserRole.removeAll user
		if (params.roles){
			if (params.roles.class.name.equals('java.lang.String')){
				UserRole.create user, Role.findByAuthority(params.roles), true
			} else{
				params.roles.each{
					UserRole.create user, Role.findByAuthority(it), true
				}
			}
		}
		
		redirect action:'user'
	}
	
	def deleteUser = {
		User user = User.get(params.id)
		UserRole.findAllByUser(user).each{
			UserRole.removeAll user
		}
		user.delete(flush:true)
		redirect action:'user'
	}
	
	// ROLE MANAGEMENT -----------------
	def role = {
		render view:'/m-melanin-fingerprint/m-melanin-fingerprint-role'
	}
	
	def findUsersByRole = {
		def users = UserRole.findAllByRole(Role.get(params.id)).user
		render users as JSON
	}
	
	def addRole = {
		if (params.roleId){
			redirect action:'editRole', params:params
			return
		}
		Role role = new Role(params)
		role.save(flush:true)
		def arr_users = []
		if (params.users){
			if (params.users.class.name.equals(java.lang.String)){
				UserRole.create User.get(params.users), role
			} else{
				params.users.each{
					UserRole.create User.get(it), role
				}
			}
		}
		redirect action:'role'
	}
	
	def editRole = {
		Role role = Role.get(params.roleId)
		springSecurityService.updateRole(role, params)
		UserRole.removeAll role
		if (params.users){
			if (params.users.class.name.equals(java.lang.String)){
				UserRole.create User.get(params.users), role
			} else{
				params.users.each{
					UserRole.create User.get(it), role
				}
			}
		}
		redirect action:'role'
	}
	
	def deleteRole = {
		Role role = Role.get(params.id)
		springSecurityService.deleteRole(role)
		redirect action:'role'
	}
	
	// REQUEST MAP MANAGEMENT ----------------
	def requestmap = {
		render view:'/m-melanin-fingerprint/m-melanin-fingerprint-requestmap'
	}
	
	def addRequestmap = {
		if (params.requestmapId){
			redirect action:'editRequestmap', params:params
			return
		}
		RequestMap rm = new RequestMap(params).save(flush:true)
		springSecurityService.clearCachedRequestmaps()
		redirect action:'requestmap'
	}
	
	def editRequestmap = {
		RequestMap rm = RequestMap.get(params.requestmapId)
		rm.properties = params
		rm.save(flush:true)
		springSecurityService.clearCachedRequestmaps()
		redirect action:'requestmap'
	}
	
	def deleteRequestmap = {
		RequestMap rm = RequestMap.get(params.id)
		rm.delete(flush:true)
		springSecurityService.clearCachedRequestmaps()
		redirect action:'requestmap'
	}
}
