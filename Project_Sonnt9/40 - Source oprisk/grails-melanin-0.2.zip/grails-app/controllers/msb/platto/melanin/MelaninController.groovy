package msb.platto.melanin
import msb.platto.fingerprint.User
import org.codehaus.groovy.grails.plugins.springsecurity.SpringSecurityUtils

class MelaninController{
	def springSecurityService
	def changePassword = {
		
		if(!params.oldPassword || !params.newPassword){ render '-1'; return}
		
		def user = User.findByUsername(springSecurityService.principal.username)
		if(user.password == springSecurityService.encodePassword(params.oldPassword)){
			user.password = params.newPassword
			render user.save(flush:true)?'1':'-1'
		}else{
			render '-1'
		}
		
	}
	def switchDashboard = {
		if (springSecurityService.isLoggedIn()) {
			def u = User.findByUsername(springSecurityService.principal.username)
			u.lastLogin = new Date()
			u.save(flush:true)
		}
		def mappings = grailsApplication.config.msb.platto.fingerprint.defaultUrlMappings
		def redirected = false
		if(mappings){
			mappings.each{ k,v->
				if(!redirected && SpringSecurityUtils.ifAnyGranted(k)){
					redirect uri:v
					redirected = true
				}	
			}
			if(!redirected){
				mappings.each{ k,v->
					if(k=='DEFAULT'){
						redirect uri:v
						redirected = true
					}
				}
			}
		}
		if(!redirected)
			redirect uri:'/'
	}
	def index = {
		render view:'/m-melanin-dashboard'
	}
	def security = {
		render view:'/m-melanin-security'
	}
	def sample = {
		render view:'/m-melanin-test-main'
	}
	def jquery = {
		render view:'/m-melanin-jquery-ui'
	}
	def easyui = {
		render view:'/m-melanin-easy-ui'
	}
	def login = {
		render view:'/m-melanin-login'
	}
	def documentation = {
		render view:'/m-melanin-documentation'
	}
	def plugins = {
		render view:'/m-melanin-plugins'
	}
	def source = {
		render view:'/m-melanin-source'
	}
	def form = {
		render view:'/m-melanin-form'
	}
	def search = {
		render view:'/m-melanin-search'
	}
	
	def datagrid = {
		render view:'/data/datagrid_data'+params.id
	}
	def refresh = {
		render 1
	}
	def ajax_login = {
		render 'abc'
	}
	
	def logout = {
		if (springSecurityService.isLoggedIn()) {
			def u = User.findByUsername(springSecurityService.principal.username)
			if(u){
				u.lastLogout = new Date()
				u.save(flush:true)
			}
		}
		redirect uri: SpringSecurityUtils.securityConfig.logout.filterProcessesUrl // '/j_spring_security_logout'
	}
}