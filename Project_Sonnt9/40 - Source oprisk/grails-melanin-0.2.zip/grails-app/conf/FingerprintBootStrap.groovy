import msb.platto.fingerprint.*
import grails.util.Environment

class FingerprintBootStrap {
	
	def springSecurityService

    def init = { servletContext ->
	
		if(Environment.current == Environment.DEVELOPMENT){
			createDevelopmentUsers()
		}
		def roles = ['ROLE_ADMIN':'Admin']
		roles.each{key,value->
			Role role =  Role.findByAuthority(key)
			if (!role){
				role = new Role(authority:key,name:value)
				//role.id = key
				role.save(flush:true)
			}
		}
		
		Role role
		User user = User.findByUsername('admin')
		if (!user){
			user = new User(username:'admin',fullname:'Admin User',
							password:'admin',
							enabled:true).save(flush:true)
			role = Role.findByAuthority('ROLE_ADMIN')
			UserRole.create user, role
		}
		
		// add request map
		if(!RequestMap.findByUrl('/fingerprint/**'))
			new RequestMap('url':'/fingerprint/**',configAttribute:'ROLE_ADMIN').save(flush:true)
		
		// add branch
		if(!Branch.findByName("MSB")){
			new Branch(name:'MSB',code:'000').save(flush:true)
		}
    }
	def createDevelopmentUsers(){
		def roles = ['ROLE_DEV':'Developer']
		roles.each{key,value->
			Role role =  Role.findByAuthority(key)
			if (!role){
				role = new Role(authority:key,name:value)
				//role.id = key
				role.save(flush:true)
			}
		}
		
		
		Role role
		User user = User.findByUsername('developer')
		if (!user){
			user = new User(username:'developer',fullname:'Developer',
							password:'developer',
							enabled:true).save(flush:true)
			role = Role.findByAuthority('ROLE_DEV')
			UserRole.create user, role
		}
		
	}
    def destroy = {
    }
}