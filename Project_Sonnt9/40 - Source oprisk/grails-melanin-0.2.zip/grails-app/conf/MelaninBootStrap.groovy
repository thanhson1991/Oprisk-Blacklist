import msb.platto.melanin.*
import msb.platto.commons.*

class MelaninBootStrap {

    def init = { servletContext ->
		//init MenuItems
		if(!MenuItem.findByName('login'))
			new MenuItem(name:'login',controller:'melanin',action:'login',
				title:'Click here to go to Login page',label:'Login',roles:'ROLE_ANONYMOUS').save(flush:true)
		if(!MenuItem.findByName('documentation'))
			new MenuItem(name:'documentation',controller:'melanin',action:'documentation',
				title:'Click here to go to documentation page',label:'Documentation',roles:'ROLE_DEV').save(flush:true)
		if(!MenuItem.findByName('sample'))
			new MenuItem(name:'sample',controller:'melanin',action:'sample',
				title:'Click here to see the sample page',label:'Sample page',roles:'ROLE_DEV').save(flush:true)
			if(!MenuItem.findByName('plugins'))
			new MenuItem(name:'plugins',controller:'melanin',action:'plugins',
				title:'Click here to see the plugins page',label:'Plugins',roles:'ROLE_DEV').save(flush:true)
		if(!MenuItem.findByName('form'))
			new MenuItem(name:'form',controller:'melanin',action:'form',
				title:'Click here to see the form & controls page',label:'Form & controls',roles:'ROLE_DEV').save(flush:true)
		if(!MenuItem.findByName('source'))
			new MenuItem(name:'source',controller:'melanin',action:'source',title:'Javascript API',label:'Javascript API',roles:'ROLE_DEV').save(flush:true)
		if(!MenuItem.findByName('security'))
			new MenuItem(name:'security',controller:'fingerprint',action:'index',
				title:'Click here to access security Control Panel',label:'Security',roles:'ROLE_ADMIN').save(flush:true)
		if(!MenuItem.findByName('control-panel'))
			new MenuItem(name:'control-panel',controller:'controlPanel',action:'index',
				title:'Click here to access Admin\'s Control Panel',label:'Control Panel',roles:'ROLE_ADMIN').save(flush:true)
		if(!Conf.findByType('welcome-text')){
			new Conf(type:'welcome-text',label:'welcome-text',value:'',ord:0,dataType:ConfType.TEXT).save(flush:true)
		}
		if(!Conf.findByType('help-file-url')){
			new Conf(type:'help-file-url',label:'help-file-url',value:'http://intranet/help',ord:0,dataType:ConfType.TEXT).save(flush:true)
		}
		
    }
	
    def destroy = {
    }
}