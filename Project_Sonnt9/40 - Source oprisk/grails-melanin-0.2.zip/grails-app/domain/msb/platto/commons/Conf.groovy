package msb.platto.commons

import msb.platto.utils.DateUtil;

class Conf {
	
	ConfType dataType
	String label
	String value
	String type
	int ord

    static constraints = {
		label	unique:true
		value 	maxSize: 10000
		type nullable: true
    }
	
	static def getValue(String label){
		Conf conf = Conf.findByLabel(label)
		if (!label){
			return null
		}
		switch (conf.dataType){
			case ConfType.TEXT:
				return conf.value
				break
				
			case ConfType.INTEGER:
				try {
					return Integer.parseInt(conf.value)
				} catch (NumberFormatException e){
					return null
				}
				break
			
			case ConfType.FLOAT:
				try {
					return Double.parseDouble(conf.value)
				} catch (NumberFormatException e){
					return null
				}
				break
			
			case ConfType.BOOLEAN:
				return Boolean.valueOf(conf.value).booleanValue()
				break
			
			case ConfType.LIST:
				return Arrays.asList(conf.value.split('\n'))
				break
			
			case ConfType.DATETIME:
				return DateUtil.parseInputShortDate(conf.value)
				break
			
			default:
				return conf.value
				break
		}
	}
}
