package msb.platto.fingerprint

class Branch implements Comparable{
    String name
	String code
    static hasMany = [children:Branch,users:User]
    static belongsTo=[parent:Branch]

    SortedSet children

    static constraints={
        parent nullable:true
		code nullable:true
    }


    static mapping = {
        sort 'name'
    }

    int compareTo(o) {
        return this.name.compareTo(o.name)
    }
}
