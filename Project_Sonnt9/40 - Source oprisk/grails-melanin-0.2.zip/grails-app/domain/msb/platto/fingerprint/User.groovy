package msb.platto.fingerprint

class User {

	transient springSecurityService

	String fullname
	String username
	String password
	boolean enabled
	boolean accountExpired
	boolean accountLocked
	boolean passwordExpired
	
	Branch branch
	String prop1
	String prop2
	String prop3
	String prop4
	String prop5
	Date lastLogin
	Date lastLogout

	static constraints = {
		username blank: false, unique: true
		password blank: true
		prop1			nullable:true
		prop2			nullable:true
		prop3			nullable:true
		prop4			nullable:true
		prop5			nullable:true
		branch 			nullable:true
		lastLogin		nullable:true
		lastLogout		nullable:true
	}

	static mapping = {
		password column: 'pass'
		table 'users' 
	}

	Set<Role> getAuthorities() {
		UserRole.findAllByUser(this).collect { it.role } as Set
	}

	def beforeInsert() {
		encodePassword()
	}

	def beforeUpdate() {
		if (isDirty('password')) {
			encodePassword()
		}
	}

	protected void encodePassword() {
		password = springSecurityService.encodePassword(password)
	}
}
