package msb.platto.melanin

class MenuItem {
	
	String name
	String controller
	String action = ''
	String url
	String label
	String title
	boolean active = false
	String roles

    static constraints = {
		title		nullable:true
		controller	nullable:true
		url			nullable:true
    }
}
