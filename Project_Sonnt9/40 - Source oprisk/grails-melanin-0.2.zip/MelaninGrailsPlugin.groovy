class MelaninGrailsPlugin {
    // the plugin version
    def version = "0.2"
    // the version or versions of Grails the plugin is designed for
    def grailsVersion = "1.3.5 > *"
    // the other plugins this plugin depends on
    def dependsOn = [
		'jqueryUi':"1.8 > *",
		'hibernate':"1.3 > *",
		'mysqlConnectorj':'5.1.12 > *',
		'springSecurityLdap':'1.0.5 > *']
    // resources that are excluded from plugin packaging
    def pluginExcludes = [
            "grails-app/views/error.gsp"
    ]

    // TODO Fill in these fields
    def author = "Solution Development Department - IT - Maritime Bank"
    def authorEmail = "cnnh.ptud@msb.com.vn"
    def title = "Melanin Plugin"
    def description = '''\\
This plugin provides security, GUI
'''

    // URL to the plugin's documentation
    def documentation = "http://grails.org/plugin/melanin"

    def doWithWebDescriptor = { xml ->
        // TODO Implement additions to web.xml (optional), this event occurs before 
    }

    def doWithSpring = {
        DateRegistrar(msb.platto.commons.DateRegistrar) {
	    	dateEditor = { msb.platto.commons.CustomDateEditor e ->
	      		formats = ['dd/MM/yyyy','yy-MM-dd HH:mm', 'yy-MM-dd', 'MM/dd/yy HH:mm', 'MM/dd/yy']
	      		allowEmpty = true
	  		}
		}

    }

    def doWithDynamicMethods = { ctx ->
        // TODO Implement registering dynamic methods to classes (optional)
    }

    def doWithApplicationContext = { applicationContext ->
        // TODO Implement post initialization spring config (optional)
    }

    def onChange = { event ->
        // TODO Implement code that is executed when any artefact that this plugin is
        // watching is modified and reloaded. The event contains: event.source,
        // event.application, event.manager, event.ctx, and event.plugin.
    }

    def onConfigChange = { event ->
        // TODO Implement code that is executed when the project configuration changes.
        // The event is the same as for 'onChange'.
    }
}
