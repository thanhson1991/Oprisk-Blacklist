//
// This script is executed by Grails after plugin was installed to project.
// This script is a Gant script so you can use all special variables provided
// by Gant (such as 'baseDir' which points on project base dir). You can
// use 'ant' to access a global instance of AntBuilder
//
// For example you can create directory under project tree:
//
//    ant.mkdir(dir:"${basedir}/grails-app/jobs")
//
updateConfig()
updateMappings()
updateDataSource()
updateI18n()

private void updateMappings(){
		def fileLocation = "${basedir}/grails-app/conf/UrlMappings.groovy"
		def configFile = new File(fileLocation)
		if (configFile.exists()){
			boolean updated = false
			if (configFile.text.indexOf('"/"(view:"/index")') != -1){
				ant.replace(file: configFile, token: '"/"(view:"/index")', value: '"/"(controller:"/melanin",action:"login")')
				updated = true
			}
			if (configFile.text.indexOf('''"500"(view:'/error')''') != -1){
				ant.replace(file: configFile, token: '''"500"(view:'/error')''', 
				value: '''
				"500"(view:'/errors/500')
				"401"(view:'/errors/403')
				"403"(view:'/errors/403')
				"404"(view:'/errors/404')
				''')
				updated = true
			}
			
			ant.mkdir(dir: "${basedir}/grails-app/views/errors")
			ant.copy(file: "${melaninPluginDir}/grails-app/views/errors/403.gsp",
			         todir: "${basedir}/grails-app/views/errors")
			ant.copy(file: "${melaninPluginDir}/grails-app/views/errors/404.gsp",
			         todir: "${basedir}/grails-app/views/errors")
			ant.copy(file: "${melaninPluginDir}/grails-app/views/errors/500.gsp",
			         todir: "${basedir}/grails-app/views/errors")					
			
			
			

			if (updated){
				ant.echo '''
	*****************************************************************
	* Your grails-app/conf/UrlMappings.groovy has been updated with *
	* default configurations of Melanin;                            *
	* please verify that the values are correct.                    *
	*****************************************************************
	'''
			}
		}
}
private void updateConfig() {
	def configFile = new File(basedir, 'grails-app/conf/Config.groovy')
	if (configFile.exists() && configFile.text.indexOf("//@melanin") == -1) {
		configFile.withWriterAppend {
			it.writeLine '\n// Added by the Melanin plugin:'
			it.writeLine '''//@melanin
//Domain mapping configurations for Spring Security Core
grails.plugins.springsecurity.userLookup.userDomainClassName = 'msb.platto.fingerprint.User'
grails.plugins.springsecurity.userLookup.authorityJoinClassName = 'msb.platto.fingerprint.UserRole'
grails.plugins.springsecurity.authority.className = 'msb.platto.fingerprint.Role'
grails.plugins.springsecurity.requestMap.className = 'msb.platto.fingerprint.RequestMap'
grails.plugins.springsecurity.securityConfigType = grails.plugins.springsecurity.SecurityConfigType.Requestmap
grails.plugins.springsecurity.auth.loginFormUrl = '/melanin/login'
grails.plugins.springsecurity.failureHandler.defaultFailureUrl = '/melanin/login/?login_error=1'
grails.plugins.springsecurity.successHandler.defaultTargetUrl = '/melanin/switchDashboard'
grails.plugins.springsecurity.successHandler.alwaysUseDefaultTargetUrl = true

//Spring Security LDAP Plugin Config
grails.plugins.springsecurity.ldap.context.managerDn = 'cn=ADInquiry,OU=MSB Service,DC=msb,DC=com,DC=vn'
grails.plugins.springsecurity.ldap.context.managerPassword = 'ADInquiry'
grails.plugins.springsecurity.ldap.context.server = 'ldap://10.1.16.1:3268'
grails.plugins.springsecurity.ldap.authorities.groupSearchBase = 'cn=ADInquiry,OU=MSB Service,DC=msb,DC=com,DC=vn'
grails.plugins.springsecurity.ldap.search.base = 'DC=msb,DC=com,DC=vn'

grails.plugins.springsecurity.ldap.search.filter="sAMAccountName={0}" // for Active Directory you need this
grails.plugins.springsecurity.ldap.search.searchSubtree = true
grails.plugins.springsecurity.ldap.auth.hideUserNotFoundExceptions = false

// Often all role information will be stored in LDAP,
// but if you want to also assign application-specific roles to users in the database,
// then add this to do an extra database lookup after the LDAP lookup.
grails.plugins.springsecurity.ldap.authorities.retrieveDatabaseRoles = true

// Application settings<br/>
msb.platto.melanin.searchController='melanin' // the search handler for the global search, you should implement this
msb.platto.melanin.searchAction='search' // the search handler for the global search, you should implement this
msb.platto.melanin.appDescription='AppName - Change this in conf/Config.groovy' // this will appear next to your logo
msb.platto.melanin.appTimeOut=1000
msb.platto.fingerprint.defaultUrlMappings = [ROLE_ADMIN:'/fingerprint',ROLE_DEVELOPER:'/melanin/documentation'] // default page for each roles
msb.platto.melanin.javascriptFiles = ['application.js']
//--@melanin--
'''

ant.echo '''
************************************************************
* Your grails-app/conf/Config.groovy has been updated with *
* default configurations of Melanin;                       *
* please verify that the values are correct.               *
************************************************************
'''
		}
	}
}

private void updateDataSource() {
	datasourceFile = "${basedir}/grails-app/conf/DataSource.groovy"
	def dsFile = new File(datasourceFile)
	if (dsFile.exists()){
		boolean updated = false
		if (dsFile.text.indexOf('password = ""') != -1){
			ant.replace(file: datasourceFile, token: 'password = ""', value: 'password = "msb"')
			updated = true
		}
		
		if (dsFile.text.indexOf('_development"') != -1){
			ant.replace(file: datasourceFile, token: '_development"', value: '_development?useUnicode=yes&characterEncoding=UTF-8&autoReconnect=true"')
			updated = true
		}
		
		if (dsFile.text.indexOf('_test"') != -1){
			ant.replace(file: datasourceFile, token: '_test"', value: '_test?useUnicode=yes&characterEncoding=UTF-8&autoReconnect=true"')
			updated = true
		}
		
		if (dsFile.text.indexOf('_production"') != -1){
			ant.replace(file: datasourceFile, token: '_production"', value: '_production?useUnicode=yes&characterEncoding=UTF-8&autoReconnect=true"')
			updated = true
		}
		
		if (updated){
			ant.echo '''
****************************************************************
* Your grails-app/conf/DataSource.groovy has been updated with *
* default configurations of Melanin;                           *
* please verify that the values are correct.                   *
****************************************************************
'''
		}
	}
}

private void updateI18n() {
	def i18nFile = new File(basedir, 'grails-app/i18n/messages.properties')
	if (i18nFile.exists() && i18nFile.text.indexOf("//@melanin") == -1) {
		i18nFile.withWriterAppend {
			it.writeLine '\n// Added by the Melanin plugin:'
			it.writeLine '''//@melanin
msb.platto.fingerprint.user.prop1=Prop1
msb.platto.fingerprint.user.prop1CssClass=Prop1 Css Class
msb.platto.fingerprint.user.prop1Help=Prop1 Help
msb.platto.fingerprint.user.prop2=Prop2
msb.platto.fingerprint.user.prop2CssClass=Prop2 Css Class
msb.platto.fingerprint.user.prop2Help=Prop2 Help
msb.platto.fingerprint.user.prop3=Prop3
msb.platto.fingerprint.user.prop3CssClass=Prop3 Css Class
msb.platto.fingerprint.user.prop3Help=Prop3 Help
//--@melanin--
'''

ant.echo '''
******************************************************************
* Your grails-app/i18n/messages.properties has been updated with *
* default configurations of Melanin;                             *
* please verify that the values are correct.                     *
******************************************************************
'''
		}
	}
}