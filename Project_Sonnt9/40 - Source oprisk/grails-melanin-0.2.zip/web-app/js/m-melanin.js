$(function(){
	$(".m-melanin-tooltip").tooltip({
		// tweak the position
	   offset: [-5, 40],
	   // use the "slide" effect
	   effect: 'slide'

	});
	$(".m-melanin-toggle-side-bar").click(function(){
		toggle_side_bar();
	});
	$("#load_spinner").dialog({
	    bgiframe: true,
	    modal: true,
	    autoOpen: false
	});
	$(window).scroll( function() {
		if($('#m-melanin-tab-header').length > 0){
	        if ($(window).scrollTop() > $('#m-melanin-tab-header').offset().top){
	            $('#m-melanin-tab-header-inner').addClass('floating');
	            $('#m-melanin-tab-header-inner').width($('#m-melanin-tab-header').width());
	        }else{
	            $('#m-melanin-tab-header-inner').removeClass('floating');
	        }
		}
    } );
	
	$.ajaxSetup({
			error:function(x,e){
				if(x.status==0 || e=='timeout'){
					jquery_alert('Thông báo','Mạng có vấn đề: xin vui lòng kiểm tra lại dây mạng/wifi.');
				}else if(x.status==401 || x.status==403 || x.responseText.error=='access denied'){
					jquery_alert('Thông báo','Bạn đã bị log out khỏi phần mềm hoặc không có quyền truy cập chức năng này. Xin vui lòng <strong><u>lưu lại các dữ liệu đang xử lý vào file word bên ngoài</u></strong> và login lại.');
				}else {
					jquery_alert_default_error();
				}
			}
		});
	
	$("input.m-melanin-datepicker").datepicker({dateFormat:'dd/mm/yy'});
		
});
function parse_money(number,locale){
	var locale = locale?locale:'vn';
	var format = (locale == 'vn'?'#,###':'#,###.00');
	return $.parseNumber(number, {format:format,locale:locale});
}
function format_money(number,locale){
	var locale = locale?locale:'vn';
	var format = (locale == 'vn'?'#,###':'#,###.00');
	return $.formatNumber(number, {format:format,locale:locale});
}
var m_melanin_side_bar = false;
function toggle_side_bar(){
	m_melanin_side_bar = !m_melanin_side_bar;
	set_side_bar(m_melanin_side_bar);
}
function set_side_bar(flag){
	m_melanin_side_bar = flag;
	if(flag){
		$("#m-melanin-page-wrap").addClass("m-melanin-left-sidebar")
	}else{
		$("#m-melanin-page-wrap").removeClass("m-melanin-left-sidebar");
	}
}
function clear_tabs(){
	$("#m-melanin-navigation ul").html('');
}
function add_tab(href,title,id,order){
	
	// check for existing menu
	if($("#m-melanin-menu-"+id).length > 0) return;
	
	// TODO: implement add tab with order
	if(order){
		console.log('function add_tab(href,title,id,order): Not implemented. Please do not pass in "order" parameter');
	}
	$("#m-melanin-navigation ul").append(
		'<li><a href="'+href+'" title="'+title+'"'+
				' id="m-melanin-menu-'+id+'"><span>'+title+'</span>'+
		'</a></li>'
		);
	
}
function set_active_tab(tab){
	$("#m-melanin-navigation a").removeClass('active');
	$("#m-melanin-navigation #m-melanin-menu-"+tab).addClass('active');
}

function jquery_alert_default_error(){
	jquery_alert('Thông báo','Lỗi hệ thống: xin vui lòng liên hệ IT Service Desk');
}

function jquery_alert(title,content,callback){

    var div = '<div id="alert_dialog" title="'+title+'" style="display: none">'+
        '<p>'+content+'</p>'+
        '</div>';

    $("body").append(div);

    $("#alert_dialog").dialog({
        bgiframe: true,
        modal: true,
        buttons: {
            OK: function() {
                $(this).dialog('close');
                $("#alert_dialog").replaceWith('');
                if(callback) callback();
            }
        }
    });
}
function jquery_input(title,content,callback){
	var div = '<div id="m_melanin_input_dialog" title="'+title+'" style="display: none">'+
    '<p>'+content+'</p>'+
    '<input name="m_melanin_input_dialog_value" type="text" class="e-xxl"/>'
    '</div>';

	$("body").append(div);
	
	$("#m_melanin_input_dialog").dialog({
	    bgiframe: true,
	    modal: true,
	    buttons: {
	        OK: function() {
	        	$(this).dialog('close');
	        	callback($("#m_melanin_input_dialog input[name=m_melanin_input_dialog_value]").val());
	            $("#m_melanin_input_dialog").replaceWith('');
	            
	        },
	        Cancel: function() {
	            $(this).dialog('close');
	            $("#m_melanin_input_dialog").replaceWith('');
	        }
	    }
	});
}
function jquery_confirm(title,content,callback,cancelCallback){

    var div = '<div id="alert_dialog" title="'+title+'" style="display: none">'+
        '<p>'+content+'</p>'+
        '</div>';

    $("body").append(div);

    $("#alert_dialog").dialog({
        bgiframe: true,
        modal: true,
        buttons: {
            OK: function() {
                $(this).dialog('close');
                $("#alert_dialog").replaceWith('');
                if(callback) callback();
            },
            Cancel: function() {
                $(this).dialog('close');
                $("#alert_dialog").replaceWith('');
                if(cancelCallback) cancelCallback();
            }
        }
    });
}

function jquery_open_load_spinner(){
    $("#load_spinner").dialog('open');
}
function jquery_close_load_spinner(){
    $("#load_spinner").dialog('close');
}
function growl(message,type,title){
	if(!type)
		type='alert';
	if(!title)
		title = 'Thông báo';

	$.pnotify({
		pnotify_title: title,
		pnotify_text: message,
		pnotify_type: type,
		pnotify_opacity: .9
	});
}
Number.prototype.padLeft = function(width, char) {
  if (!char) {
    char = " ";
  }

  if (("" + this).length >= width) {
    return "" + this;
  }
  else {
    return arguments.callee.call(
      char + this, 
      width, 
      char
    );
  }
}